This resource pack is empty, you can add contents on this URL:
http://

Put the "assets" folder into this pack and use it as your server's resource pack.

Current Version: 1.5
All Partitions:
- Survival Rework
- Texture Rework
- Combat Rework
  - Bow Rework
  - Medical Kit
  - Reinforced Leather Armor
- Farming Products
  - Beetroot Sandwich
- Legendary Items
  - Legendary Weapons
  - Gold Armor Buff